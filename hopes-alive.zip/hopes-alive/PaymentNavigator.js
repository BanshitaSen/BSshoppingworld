import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import PaymentScreen from './screens/PaymentScreen';

const Stack = createStackNavigator();

const PaymentNavigator = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Payment" component={PaymentScreen} options={{ headerShown: false }} />
      <Stack.Screen name="OrderConfirmation" component={OrderConfirmationScreen} options={{ headerShown: false }} />
    </Stack.Navigator>
  );
};

export default PaymentNavigator;
