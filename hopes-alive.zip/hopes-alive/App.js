import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import GettingStartedScreen from './screens/GettingStartedScreen';
import LoginScreen from './screens/LoginScreen';
import SignupScreen from './screens/SignupScreen';
import SuccessScreen from './screens/SuccessScreen';
import ProductScreen from './screens/ProductsScreen';
import FavoriteScreen from './screens/FavoritesScreen';
import OrderScreen from './screens/OrdersScreen';
import ProfileScreen from './screens/ProfileScreen';
import { NavigationProvider } from './navigationContext';
import { FavoritesProvider } from './FavoriteContext';
import { OrderProvider } from './OrderContext';

const Stack = createStackNavigator();

const App = () => {
  const [initialRoute, setInitialRoute] = useState('GettingStarted');

  useEffect(() => {
    const checkUser = async () => {
      const user = await AsyncStorage.getItem('user');
      if (user) {
        setInitialRoute('Product');
      }
    };
    checkUser();
  }, []);

  return (
    <OrderProvider>
      <FavoritesProvider>
        <NavigationProvider>
          <NavigationContainer>
            <Stack.Navigator initialRouteName={initialRoute}>
              <Stack.Screen name="GettingStarted" component={GettingStartedScreen} options={{ headerShown: false }}/>
              <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
              <Stack.Screen  name="Signup"  component={SignupScreen} options={{ headerShown: false }}/>
              <Stack.Screen name="Success" component={SuccessScreen} options={{ headerShown: false }} />
              <Stack.Screen name="Product" component={ProductScreen} options={{ headerShown: false }}/>
              <Stack.Screen name="Favorites" component={FavoriteScreen} options={{ headerShown: false }} />
              <Stack.Screen name="Order" component={OrderScreen} options={{ headerShown: false }}/>
              <Stack.Screen name="Profile" component={ProfileScreen} options={{ headerShown: false }}/>
            </Stack.Navigator>
          </NavigationContainer>
        </NavigationProvider>
      </FavoritesProvider>
    </OrderProvider>
  );
};

export default App;
