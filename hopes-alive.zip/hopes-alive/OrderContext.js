import React, { createContext, useState } from 'react';
export const OrderContext = createContext();
export const OrderProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const addToCart = (product) => {
    setCart([...cart, product]);
  };
  const removeFromCart = (productId) => {
    setCart(cart.filter(item => item.id !== productId));
  };
  return (
    <OrderContext.Provider value={{ cart, addToCart, removeFromCart }}>
      {children}
    </OrderContext.Provider>
  );
};
