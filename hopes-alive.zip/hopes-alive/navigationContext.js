import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const NavigationContext = createContext();

export const NavigationProvider = ({ children }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const storedUsername = await AsyncStorage.getItem('username');
        const storedEmail = await AsyncStorage.getItem('email');
        if (storedUsername && storedEmail) {
          setUsername(storedUsername);
          setEmail(storedEmail);
        }
      } catch (error) {
        console.error('Failed', error);
      }
    };

    loadUserData();
  }, []);
  const loginUser = async (email, password) => {
    try {
      const storedEmail = await AsyncStorage.getItem('email');
      const storedPassword = await AsyncStorage.getItem('password');
      if (email === storedEmail && password === storedPassword) {
        setUsername(await AsyncStorage.getItem('username'));
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login failed', error);
      return false;
    }
  };
  const addUser = async (username, email, password) => {
    try {
      const existingEmail = await AsyncStorage.getItem('email');
      if (existingEmail) {
        return false;
      }
      await AsyncStorage.multiSet([
        ['username', username],
        ['email', email],
        ['password', password],
      ]);

      setUsername(username);
      setEmail(email);
      return true;
    } catch (error) {
      console.error('Error', error);
      return false;
    }
  };
  return (
    <NavigationContext.Provider value={{ username, email, loginUser, addUser }}>
      {children}
    </NavigationContext.Provider>
  );
};

export const useNavigationContext = () => useContext(NavigationContext);