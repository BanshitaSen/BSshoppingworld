import React, { useContext } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image, Alert } from 'react-native';
import { OrderContext } from '../OrderContext';

const OrdersScreen = ({ navigation }) => {
  const { cart, removeFromCart } = useContext(OrderContext);

  const handleOrderNow = () => {
    Alert.alert('HURRAY ORDER PLACED', 'Happy Shopping');
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {cart.length > 0 ? (
          cart.map(product => (
            <View key={product.id} style={styles.productCard}>
              <Image source={{ uri: product.image }} style={styles.image} />
              <Text style={styles.name}>{product.name}</Text>
              <Text style={styles.description}>{product.description}</Text>
              <TouchableOpacity style={styles.button} onPress={() => removeFromCart(product.id)}>
                <Text style={styles.buttonText}>Remove</Text>
              </TouchableOpacity>
            </View>
          ))
        ) : (
          <Text style={styles.emptyMessage}>No order yet</Text>
        )}
      </ScrollView>
      {cart.length > 0 && (
        <View style={styles.footer}>
          <TouchableOpacity style={styles.paymentButton} onPress={handleOrderNow}>
            <Text style={styles.paymentButtonText}>Order Now</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: 'lightpink',
    justifyContent: 'space-between',
  },
  scrollContainer: {
    paddingBottom: 20,
  },
  productCard: {
    backgroundColor: 'lightpink',
    padding: 15,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  image: {
    width: 150,
    height: 150,
    marginBottom: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  description: {
    textAlign: 'center',
  },
  button: {
    backgroundColor: 'red',
    padding: 5,
    borderRadius: 5,
    marginHorizontal: 5,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  },
  emptyMessage: {
    fontSize: 18,
    textAlign: 'center',
    marginTop: 20,
  },
  footer: {
    paddingVertical: 10,
  },
  paymentButton: {
    backgroundColor: '#E0115F',
    padding: 10,
    marginHorizontal: 20,
    alignItems: 'center',
    borderRadius: 5,
  },
  paymentButtonText: {
    color: '#ADD8E6',
    fontSize: 15,
  },
});

export default OrdersScreen;