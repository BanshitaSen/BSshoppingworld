import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { useNavigationContext } from '../navigationContext';
import { createDrawerNavigator, DrawerContentScrollView } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';
import FavoritesScreen from './FavoritesScreen';
import ProductsScreen from './ProductsScreen';
import OrdersScreen from './OrdersScreen';
import PaymentScreen from './PaymentScreen';
import ProfileScreen from './ProfileScreen';

const Drawer = createDrawerNavigator();

const CustomDrawerItem = ({ label, onPress, icon }) => {
  return (
    <TouchableOpacity onPress={onPress} style={styles.drawerItem}>
      <Icon name={icon} size={18} style={styles.drawerIcon} />
      <Text style={styles.drawerLabel}>{label}</Text>
    </TouchableOpacity>
  );
};

const CustomDrawerContent = (props) => {
  const { username, navigation } = props;

  return (
    <DrawerContentScrollView {...props} contentContainerStyle={styles.drawerContainer}>
      <View style={styles.drawerHeader}>
        <Text style={styles.drawerHeaderText}>Welcome!</Text>
      </View>
      <CustomDrawerItem label="Profile" onPress={() => navigation.navigate('Profile')} icon="person-outline" />
      <CustomDrawerItem label="Products" onPress={() => navigation.navigate('Products')} icon="pricetag-outline"/>
      <CustomDrawerItem label="Orders" onPress={() => navigation.navigate('Orders')} icon="cart-outline" />
      <CustomDrawerItem label="Wishlist" onPress={() => navigation.navigate('Favorites')} icon="heart-outline" />
    </DrawerContentScrollView>
  );
};

const HomeScreen = ({ navigation }) => {
  const { username } = useNavigationContext();

  const offers = [
    { image: { uri: 'https://coreldrawdesign.com/resources/thumbnails/thumbnail-1709372572.jpg' } },
    { image: { uri: 'https://content.wepik.com/statics/20891781/preview-page0.jpg' } },
    { image: { uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTDPkcEaYvjhptRGn56HbjdW83i3BeHXvAgCQ&s' } },
  ];

  const categories = [
    { name: 'Electronics', image: { uri: 'https://img.lovepik.com/free-png/20210928/lovepik-mobile-phone-png-image_401663651_wh1200.png' } },
    { name: 'Clothing', image: { uri: 'https://t3.ftcdn.net/jpg/01/99/82/42/360_F_199824276_somlbrYKh1XlUnyvLbn3xwjZLlXvEkHx.jpg' } },
    { name: 'Decor', image: { uri: 'https://media.istockphoto.com/id/1363806451/photo/stylish-living-room-interior-design-with-console-and-mock-up-poster-frame-lamp-vase-and.jpg?s=612x612&w=0&k=20&c=HchChU_rqkLR80TrTdKPUhf-7gQnuuNmeis3-Ui8MmI=' } },
    { name: 'Beauty', image: { uri: 'https://media.istockphoto.com/id/1296705483/photo/make-up-products-prsented-on-white-podiums-on-pink-pastel-background.jpg?s=612x612&w=0&k=20&c=j3Vfpo81L5I2g0uJ5tArBC3l_fcPtPAcLzzT4pq5BLY=' } },
    { name: 'Shoes', image: { uri: 'https://cdn.pixabay.com/photo/2015/01/03/03/51/sandals-587185_640.jpg' } },
    { name: 'Toys', image: { uri: 'https://media.istockphoto.com/id/687165852/photo/toys.jpg?s=612x612&w=0&k=20&c=_BdsQLnut3pVc3RYgodD3Xiy7gCCM3K8HX3GdODLRt0=' } },
    { name: 'Grocery', image: { uri: 'https://media.istockphoto.com/id/171302954/photo/groceries.jpg?s=612x612&w=0&k=20&c=D3MmhT5DafwimcYyxCYXqXMxr1W25wZnyUf4PF1RYw8=' } },
  ];

  const featuredImages = [
    { uri: 'https://nestasia.in/cdn/shop/files/DSCF3863.jpg?v=1689316133', name: 'Victorian Wall Mirror Gold', price: 'Rs 7689/-' },
    { uri: 'https://img.freepik.com/premium-photo/luxury-lipstick-white-background_398492-11482.jpg', name: 'Maybelline Red Matte Lipstick', price: 'Rs 699/-' },
    { uri: 'https://dressmeroyal.com/wp-content/uploads/2023/03/White-Chiankari-Lehenga-1-jpg.webp', name: 'White Pink Semi-Stitched Lehenga', price: 'Rs 2399/-' },
    { uri: 'https://img.lovepik.com/photo/20211201/small/lovepik-lady-bags-picture_501296987.jpg', name: 'Caprese Beige Tote Bag', price: 'Rs 1349/-' },
    { uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9lYB3hEdWYJtR7AgpPsyFgRigPGjILZsMCg&s', name: 'Mens Brown Shoes', price: 'Rs 569/-' },
    { uri: 'https://m.media-amazon.com/images/I/71ri5xbzy1L._AC_UF1000,1000_QL80_.jpg', name: 'Kids Toys Kitchen Set', price: 'Rs 448/-' },
  ];

  const handleCategoryPress = (category) => {
    navigation.navigate('Products', { category });
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollViewContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.offersContainer}>
          {offers.map((offer, index) => (
            <Image key={index} source={offer.image} style={styles.offerImage} />
          ))}
        </ScrollView>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoriesContainer}>
          {categories.map((category, index) => (
            <TouchableOpacity key={index} style={styles.categoryItem} onPress={() => handleCategoryPress(category.name)}>
              <Image source={category.image} style={styles.categoryImage} />
              <Text style={styles.categoryName}>{category.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        <ScrollView contentContainerStyle={styles.featuredContainer} showsVerticalScrollIndicator={false}>
          {featuredImages.map((img, index) => (
            <View key={index} style={styles.featuredImageContainer}>
              <Image source={{ uri: img.uri }} style={styles.featuredImage} />
              <Text style={styles.featuredImageName}>{img.name}</Text>
              <Text style={styles.featuredImagePrice}>{img.price}</Text>
            </View>
          ))}
        </ScrollView>
      </ScrollView>
    </View>
  );
};

const Footer = ({ navigation }) => {
  return (
    <View style={styles.footer}>
      <Icon name="home-outline" size={20} onPress={() => navigation.navigate('Home')} />
      <Icon name="heart-outline" size={20} onPress={() => navigation.navigate('Favorites')} />
      <Icon name="cart-outline" size={20} onPress={() => navigation.navigate('Orders')} />
    </View>
  );
};

const ScreenWithFooter = (ScreenComponent) => (props) => {
  const { navigation } = props;
  return (
    <View style={{ flex: 1 }}>
      <ScreenComponent {...props} />
      <Footer navigation={navigation} />
    </View>
  );
};

const SuccessScreen = () => {
  const { username } = useNavigationContext();

  return (
    <NavigationContainer independent={true}>
      <Drawer.Navigator
        drawerContent={(props) => <CustomDrawerContent {...props} username={username} />}
        screenOptions={{
          drawerStyle: {
            backgroundColor: '#E0115F', },
          drawerActiveTintColor: '#ADD8E6', 
          drawerInactiveTintColor: 'lightgrey', 
          drawerLabelStyle: {fontSize: 14},
          headerStyle: { backgroundColor: '#E0115F'},
          headerTitleStyle: {color: '#ADD8E6' },
          headerTintColor: '#ADD8E6'}}
        initialRouteName="Home">
        <Drawer.Screen name="Home" component={ScreenWithFooter(HomeScreen)} />
        <Drawer.Screen name="Favorites" component={ScreenWithFooter(FavoritesScreen)} />
        <Drawer.Screen name="Products" component={ScreenWithFooter(ProductsScreen)} />
        <Drawer.Screen name="Orders" component={ScreenWithFooter(OrdersScreen)} />
        <Drawer.Screen name="Profile" component={ScreenWithFooter(ProfileScreen)} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: 'lightpink',
  },
  scrollViewContainer: {
    flexGrow: 1,
  },
  offersContainer: {
    flexDirection: 'row',
    paddingVertical: 0, 
  },
  offerImage: {
    width: 350,
    height: 260, 
    marginRight: 10,
  },
  categoriesContainer: {
    flexDirection: 'row',
    paddingVertical: 0,
  },
  categoryItem: {
    alignItems: 'center',
    marginHorizontal: 15, 
  },
  categoryImage: {
    marginTop: 10,
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  categoryName: {
    fontSize: 14, 
  },
  featuredContainer: {
    flexDirection: 'column', 
    paddingVertical: 10,
  },
  featuredImageContainer: {
    marginBottom: 10, 
  },
  featuredImage: {
    width: '100%',
    height: 250,
  },
  featuredImageName: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  featuredImagePrice: {
    fontSize: 14,
    color: '#E0115F',
    textAlign: 'center',
  },
  footer: {
    height: 45,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    borderTopWidth: 1,
    backgroundColor: '#E0115F',
  },
  drawerContainer: {
    flex: 1,
    backgroundColor: '#E0115F', 
  },
  drawerHeader: {
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#E0115F', 
    paddingVertical: 10,
  },
  drawerHeaderText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ADD8E6',
  },
  drawerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
  },
  drawerIcon: {
    marginRight: 8,
    color: '#ADD8E6',
  },
  drawerLabel: {
    fontSize: 12,
    color: '#ADD8E6',
  },
});

export default SuccessScreen;
