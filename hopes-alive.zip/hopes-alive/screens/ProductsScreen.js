import React, { useContext } from 'react';
import { View, Text, Image, ScrollView, StyleSheet, Button, TouchableOpacity } from 'react-native';
import { FavoritesContext } from '../FavoriteContext';
import { OrderContext } from '../OrderContext';

const products = [
  { id: 1, name: 'Womens Printed Shirt Tops', description: 'Rs 345/-', image: 'https://i.pinimg.com/564x/bf/b1/06/bfb106b294875047671a6d1fd4526b0f.jpg', section: 'clothing' },
  { id: 2, name: 'Womens Blue Floral Dress', description: 'Rs 763/-', image: 'https://img.freepik.com/free-photo/curly-girl-beautiful-dress_144627-10112.jpg', section: 'clothing' },
  { id: 3, name: 'Womens Royal Blue Bodycon Dress', description: 'Rs 999/-', image: 'https://img.freepik.com/free-photo/sexy-white-model-elegant-blue-dress-posing-luxury-interior-studio_273443-3367.jpg', section: 'clothing' },
  { id: 4, name: 'Womens Floral Yellow Tops', description: 'Rs 345/-', image: 'https://images.jdmagicbox.com/rep/b2b/women-top/women-top-11.jpg', section: 'clothing' },
  { id: 5, name: 'Womens Tokyo Talkies Blue Skinny Jeans', description: 'Rs 1239/-', image: 'https://t4.ftcdn.net/jpg/01/66/91/49/360_F_166914999_rc4HT49NueGlWoL7QpFfJuDQrI5YW4oD.jpg', section: 'clothing' },
   { id: 6, name: 'Womens Black Wide Leg Jeans', description: 'Rs 1099/-', image: 'https://cdn02.nnnow.com/web-images/large/styles/5LE9E7I5PBA/1684921471058/1.jpg', section: 'clothing' },
   { id: 7, name: 'Womens Blue BootCut Jeans', description: 'Rs 1399/-', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShIUVgD0FLL7GY_VTcE1yvL03SXfL9g3bZrQ&s', section: 'clothing' },
  { id: 8, name: 'Samsung Stainless Steel Double Door Fridge', description: 'Rs 94109/-', image: 'https://img.freepik.com/premium-photo/silver-steel-fridge-model-isolated-white-background_124507-67356.jpg', section: 'electronics' },
  { id: 9, name: 'LG Front Open Washing Mashine', description: 'Rs 18999/-', image: 'https://media.istockphoto.com/id/172485535/photo/washing-machine.jpg?s=612x612&w=0&k=20&c=heH0vH2hfuP7QLt4lGQvILj61sD5iuzs8sZk_izSazc=', section: 'electronics' },
  { id: 10, name: 'Daikin 2.5-Ton 3-Star AC', description: 'Rs 49999/-', image: 'https://cdn.pixabay.com/photo/2021/09/08/07/20/air-conditioner-6605973_640.jpg', section: 'electronics' },
  { id: 11, name: 'Iphone 15-Pro Max', description: 'Rs 210899/-', image: 'https://fdn2.gsmarena.com/vv/pics/apple/apple-iphone-14-pro-max-1.jpg', section: 'electronics' },
  { id: 12, name: 'Prestige MicroWave Oven', description: 'Rs 34459/-', image: 'https://img.freepik.com/free-vector/microwave-oven-with-light-inside-isolated-white-background-kitchen-appliances_134830-658.jpg', section: 'electronics' },
  { id: 13, name: '1kg Cabbage', description: 'Rs 48/-', image: 'https://upload.wikimedia.org/wikipedia/commons/1/14/CabbageBG.JPG', section: 'Vegetables' },
  { id: 14, name: '1kg Capsicum', description: 'Rs 73/-', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Green-Yellow-Red-Pepper-2009.jpg/1024px-Green-Yellow-Red-Pepper-2009.jpg', section: 'Vegetables' },
  { id: 15, name: '3kg Potato', description: 'Rs 89/-', image: 'https://upload.wikimedia.org/wikipedia/commons/6/67/Potato_potato.jpg', section: 'Vegetables' },
  { id: 16, name: '1kg Tomato', description: 'Rs 34/-', image: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?cs=srgb&dl=pexels-pixabay-533280.jpg&fm=jpg', section: 'Vegetables' },
  { id: 17, name: '500g Broccoli', description: 'Rs 235/-', image: 'https://media.istockphoto.com/id/593310638/photo/broccoli-in-a-pile.jpg?s=612x612&w=0&k=20&c=jEo9Rtw1X9uuOWhQ97nmJ9d2Q341XgPROcqbWn5iwNQ=', section: 'Vegetables' },
  { id: 18, name: 'Apple', description: 'Rs 11/- per piece', image: 'https://upload.wikimedia.org/wikipedia/commons/c/c1/Fuji_apple.jpg', section: 'Fruits' },
  { id: 19, name: '250g Fresh Strawberries', description: 'Rs 237/-', image: 'https://images.pexels.com/photos/70746/strawberries-red-fruit-royalty-free-70746.jpeg?cs=srgb&dl=pexels-pixabay-70746.jpg&fm=jpg', section: 'Fruits' },
  { id: 20, name: '500g Pomegranete', description: 'Rs 103/-', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHfHr10DQEi5iqRfxYpL5E4Qb9X_HExisNdg&s', section: 'Fruits' },
  { id: 17, name: 'Orange', description: 'Rs 9/- per piece', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f9/Orange_and_cross_section.jpg/1200px-Orange_and_cross_section.jpg', section: 'Fruits' },
  { id: 18, name: '1 kg Grapes', description: 'Rs 56/-', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Grapes_in_a_bowl.JPG/1200px-Grapes_in_a_bowl.JPG', section: 'Fruits' },
  { id: 19, name: '1 kg Kelloggs Muesli', description: 'Rs 399/-', image: 'https://m.media-amazon.com/images/I/71BsckBgy3L.jpg', section: 'Cereals' },
  { id: 19, name: '1 kg Mooong Dal', description: 'Rs 59/-', image: 'https://t4.ftcdn.net/jpg/02/75/33/33/360_F_275333355_F0JGRauiN73DD2sFALYStlKqyAiCSnSX.jpg', section: 'Cereals' },
  { id: 20, name: '2 kg Aashirvaad Atta', description: 'Rs 299/- ', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/Atta-04.jpg/800px-Atta-04.jpg', section: 'Cereals' },
  { id: 21, name: '5 kg Basmati Rice', description: 'Rs 799/-', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Basmati_Rice_India%2C_raw.jpg/2560px-Basmati_Rice_India%2C_raw.jpg', section: 'Cereals' }, 
  { id: 22, name: 'Swiss Beauty Matte-Finish Lipstick', description: 'Rs 449/-', image: 'https://m.media-amazon.com/images/I/61d8UK67uHL._AC_UF1000,1000_QL80_.jpg', section: 'Beauty' }, 
  { id: 23, name: 'Huda Beauty Nude EyeShadow Palette', description: 'Rs 2399/-', image: 'https://t3.ftcdn.net/jpg/03/43/02/10/360_F_343021099_b5xJqzHOHSdLPIMotjalNKwaG8O4e0K5.jpg', section: 'Beauty' }, 
  { id: 24, name: 'MakeUp Studio Jet Black Eyeliner', description: 'Rs 279/-', image: 'https://www.make-upstudio.com/images/detailed/14/Eyeliner_-_Black-_PH0637-1.jpg', section: 'Beauty' }, 
  { id: 25, name: 'Luminious Silk Compact Powder', description: 'Rs 357/-', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAgY8nddhyyi4A1QB2lJJbnSgj-LBZvv82uQ&s', section: 'Beauty' }, 
  { id: 26, name: 'Renee Pack of 17 MakeUp Brushes', description: 'Rs 799/-', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/CA/RM/CL/153078993/makeup-brushes-jpg-500x500.jpg', section: 'Beauty' }, 
  { id: 27, name: 'Elegant Leather Shoes Black', description: 'Rs 1099/-', image: 'https://media.istockphoto.com/id/172417586/photo/elegant-black-leather-shoes.jpg?s=612x612&w=0&k=20&c=c_tTljwbu2m0AGxwb27NxCgG0Y2Cv-C4v8q6V36RYbw=', section: 'Shoes' },
  { id: 28, name: 'Nude Pencil Heels', description: 'Rs 448/-', image: 'https://cdn.pixabay.com/photo/2016/04/13/15/15/high-heels-1327020_640.jpg', section: 'Shoes' },
  { id: 29, name: 'Women Fashion Sandals', description: 'Rs 356/-', image: 'https://m.media-amazon.com/images/I/61XlLcC0WfL._AC_UY1000_.jpg', section: 'Shoes' }, 
  { id: 30, name: 'Blue Casual Flip-Flops', description: 'Rs 213/-', image: 'https://availeverything.com/public/uploads/all/lVyiiTOSANj7Wamf8U2vAvrNhCJOp3sofb16Pcil.jpg', section: 'Shoes' }, 
  { id: 31, name: 'Cute Musical Doll', description: 'Rs 658/-', image: 'https://m.media-amazon.com/images/I/61R-mfmFmXL._AC_UF1000,1000_QL80_.jpg', section: 'Toys' },
  { id: 32, name: 'Girls Barbie Set', description: 'Rs 189/-', image: 'https://m.media-amazon.com/images/I/91JhaxNX4ZL.jpg', section: 'Toys' },
  { id: 33, name: 'Cute TeddyBear Combo', description: 'Rs 256/-', image: 'https://static.vecteezy.com/system/resources/previews/033/108/991/non_2x/super-cute-teddy-bears-couple-in-love-happy-valentine-s-day-concept-background-ai-generated-image-photo.jpg', section: 'Toys' },
  { id: 34, name: 'Yellow Toy Car', description: 'Rs 256/-', image: 'https://st.depositphotos.com/1455321/1564/i/450/depositphotos_15645257-stock-photo-yellow-toy-car.jpg', section: 'Toys' },
  { id: 35, name: 'Handbags Pack of 4', description: 'Rs 568/-', image: 'https://m.media-amazon.com/images/I/61i2f6JRKoL._AC_UY1000_.jpg', section: 'Bags' },
  { id: 36, name: 'F-Gear Laptop Bagpack', description: 'Rs 3613/-', image: 'https://www.fgear.in/cdn/shop/files/1_40ba6feb-0231-429c-a5e0-db8e9018d82d.jpg?v=1689766209', section: 'Bags' },
  { id: 37, name: 'Lulu&Sky Blue Squared Sling Bag', description: 'Rs 3459/-', image: 'https://d1it09c4puycyh.cloudfront.net/catalog/product/d/y/dy-1264-bluea_copy.jpg', section: 'Bags' },
  { id: 38, name: 'DressBerry Black Shoulder Bag', description: 'Rs 799/-', image: 'https://assets.ajio.com/medias/sys_master/root/20230314/dTee/6410a111f997dde6f4f9dec6/-473Wx593H-469316761-black-MODEL.jpg', section: 'Bags' },
];

const ProductScreen = ({ username, onLogout }) => {
  const { addToFavorites } = useContext(FavoritesContext);
  const { addToCart } = useContext(OrderContext);

  const sections = [...new Set(products.map(product => product.section))];

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {sections.map(section => (
          <View key={section} style={styles.section}>
            <Text style={styles.sectionTitle}>{section}</Text>
            {products.filter(product => product.section === section).map(product => (
              <View key={product.id} style={styles.productCard}>
                <Image source={{ uri: product.image }} style={styles.image} />
                <Text style={styles.name}>{product.name}</Text>
                <Text style={styles.description}>{product.description}</Text>
                <View style={styles.buttonContainer}>
                  <TouchableOpacity style={styles.button} onPress={() => addToFavorites(product)}>
                    <Text style={styles.buttonText}>Wishlist</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.button} onPress={() => addToCart(product)}>
                    <Text style={styles.buttonText}>Add to Cart</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: 'lightpink',
    width: '100%',
  },
  scrollContainer: {
    paddingBottom: 20,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  productCard: {
    backgroundColor: 'lightpink',
    padding: 15,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  image: {
    width: 150,
    height: 150,
    marginBottom: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  description: {
    textAlign: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  button: {
    backgroundColor: '#E0115F',
    padding: 10,
    borderRadius: 5,
    flex: 1,
    marginHorizontal: 5,
  },
  buttonText: {
    color: '#ADD8E6',
    textAlign: 'center',
  },
});

export default ProductScreen;
