import React, { useEffect } from 'react';
import { View, Image, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigationContext } from '../navigationContext';
import AsyncStorage from '@react-native-async-storage/async-storage';

const GettingStartedScreen = ({ navigation }) => {
  const { setEmail, setUsername } = useNavigationContext();

  useEffect(() => {
    const checkUser = async () => {
      const user = await AsyncStorage.getItem('user');
      if (user) {
        const { email, username } = JSON.parse(user);
        setEmail(email);
        setUsername(username);
        navigation.navigate('Home'); 
      }
    };
    checkUser();
  }, []);

  return (
    <View style={styles.overlay}>
      <Image
        source={{ uri: 'https://img.freepik.com/premium-photo/pink-letter-b-floating-with-touches-yellow-orange-genarated-by-ai_1078560-9300.jpg' }}
        style={styles.topImage}
      />
      <Text style={styles.title}>BS SHOPPING WORLD</Text>
      <Text style={styles.subtitle}>. SHOP . DISCOVER . ENJOY .</Text>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Login')}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    backgroundColor: '#E0115F',
  },
  topImage: {
    width: 100, 
    height: 100, 
    marginBottom: 20, 
    borderRadius: 50,
  },
  title: {
    fontSize: 29,
    fontWeight: 'bold',
    color: '#ADD8E6',
    marginTop: 60,
    marginBottom: 20,
  },
  subtitle: {
    fontSize: 15,
    fontWeight: 'bold',
    fontStyle: 'italic',
    color: '#ADD8E6',
    marginTop: 10,
    marginBottom: 50,
  },
  button: {
    backgroundColor: '#ADD8E6',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  buttonText: {
    color: '#E0115F',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default GettingStartedScreen;
