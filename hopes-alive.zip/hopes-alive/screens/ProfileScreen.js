import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useNavigationContext } from '../navigationContext';

const ProfileScreen = () => {
  const { username, email } = useNavigationContext();

  return (
    <View style={styles.container}>
      <View style={styles.profileBox}>
        <Text style={styles.title}>Profile Info</Text>
        <View style={styles.detailRow}>
          <Text style={styles.label}>Username:</Text>
          <Text style={styles.value}>{username}</Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={styles.label}>Email:</Text>
          <Text style={styles.value}>{email}</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'lightpink',
    padding: 20,
  },
  profileBox: {
    backgroundColor: '#E0115F',
    borderRadius: 10,
    padding: 20,
    width: '90%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  title: {
    fontSize: 30,
    marginBottom: 20,
    fontWeight: 'bold',
    color: '#ADD8E6',
    textAlign: 'center',
  },
  detailRow: {
    flexDirection: 'row',
    marginVertical: 10,
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ADD8E6',
    marginRight: 10,
  },
  value: {
    fontSize: 16,
    color: 'lightpink',
    flexShrink: 1,
  },
});

export default ProfileScreen;