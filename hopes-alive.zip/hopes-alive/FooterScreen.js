const Footer = ({ navigation }) => {
  return (
    <View style={styles.footer}>
      <Icon name="home-outline" size={20} onPress={() => navigation.navigate('Home')} />
      <Icon name="heart-outline" size={20} onPress={() => navigation.navigate('Favorites')} />
      <Icon name="cart-outline" size={20} onPress={() => navigation.navigate('Orders')} />
    </View>
  );
};
