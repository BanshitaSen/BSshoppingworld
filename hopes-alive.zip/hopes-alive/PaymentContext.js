import React, { createContext, useState } from 'react';

export const PaymentContext = createContext();

export const PaymentProvider = ({ children }) => {
  const [paymentOption, setPaymentOption] = useState({
    creditCard: false,
    debitCard: false,
    paypal: false,
    bankTransfer: false,
  });

  const handleSwitchChange = (option) => {
    setPaymentOption(prevState => ({
      ...prevState,
      [option]: !prevState[option]
    }));
  };

  return (
    <PaymentContext.Provider value={{ paymentOption, handleSwitchChange }}>
      {children}
    </PaymentContext.Provider>
  );
};
